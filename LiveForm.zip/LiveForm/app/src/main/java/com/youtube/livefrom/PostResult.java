package com.youtube.livefrom;

import java.util.ArrayList;
import java.util.List;

public class PostResult {
    public static boolean Success = true;
    public static int ErrorCode = 0;
    public static List<String> Messages = new ArrayList<String>();
}
