package com.youtube.livefrom;

public class OverlayItem
{
    public String Source;
    public String Position;
    public String Duration ;
    public String Type ;
    public String FontStyle ;
    public String FontSize ;
}
